import pandas as pd
import ta

class FeatureEngineer:
    def __init__(self, window=30):
        self.window = window

    def compute_features(self, df):
        # Ensure Timestamp is in datetime format
        df['Timestamp (IST)'] = pd.to_datetime(df['Timestamp (IST)'])

        # Price Change %
        df['price_change_pct'] = df['Close'].pct_change() * 100

        # Momentum
        df['momentum_3'] = df['Close'].diff(3)
        df['momentum_5'] = df['Close'].diff(5)

        # Moving Averages (within 30-period max)
        df['ema_9'] = ta.trend.ema_indicator(df['Close'], window=9)
        df['ema_21'] = ta.trend.ema_indicator(df['Close'], window=21)

        # Average True Range (ATR)
        df['atr_5'] = ta.volatility.average_true_range(df['High'], df['Low'], df['Close'], window=5)

        # MACD
        df['macd'] = ta.trend.macd(df['Close'])
        df['macd_signal'] = ta.trend.macd_signal(df['Close'])

        # RSI
        df['rsi'] = ta.momentum.RSIIndicator(df['Close']).rsi()

        # Bollinger Bands
        bb = ta.volatility.BollingerBands(df['Close'], window=20)
        df['bb_upper'] = bb.bollinger_hband()
        df['bb_lower'] = bb.bollinger_lband()

        # Price Action Strength
        df['candle_body_size'] = abs(df['Close'] - df['Open'])
        df['wick_size'] = df['High'] - df['Low']

        # Buy/Sell Pressure
        df['buy_pressure'] = abs(df['Close'] - df['Low'])
        df['sell_pressure'] = abs(df['High'] - df['Close'])

        # ✅ Remove any future-based columns (no future_close, no future_change)

        # Fill missing values to prevent NaN
        df.ffill(inplace=True)
        df.bfill(inplace=True)

        # Return the last 12 rows as state
        return df.iloc[-12:]



