import pandas as pd
import numpy as np
import gym
from gym import spaces

class TickTradingEnv(gym.Env):
    def __init__(self, past_df, future_df):
        super(TickTradingEnv, self).__init__()

        # ✅ Reset Index For Both DataFrames
        self.past_df = past_df.reset_index(drop=True)
        self.future_df = future_df.reset_index(drop=True)

        # ✅ 12 Steps (5 Times)
        self.step_size = 12
        self.max_steps = 5
        self.current_step = 0

        # ✅ Action Space: [Hold, Buy, Sell]
        self.action_space = spaces.Discrete(3)

        # ✅ Observation Space: 12 rows × 5 columns
        self.observation_space = spaces.Box(
            low=-np.inf, 
            high=np.inf, 
            shape=(self.step_size, 5), 
            dtype=np.float32
        )

        # ✅ Track Profit & Position
        self.position = 0
        self.total_profit = 0

    def _get_observation(self):
        """
        ✅ Return the last 12 rows of past data
        """
        start = self.current_step * self.step_size
        end = start + self.step_size
        return self.past_df.iloc[start:end][['Open', 'High', 'Low', 'Close', 'Volume']].values.astype(np.float32)

    def _get_future_close(self):
        """
        ✅ Return the closing price of the future data
        """
        start = self.current_step * self.step_size
        end = start + self.step_size
        return self.future_df.iloc[start:end]['Close'].values

    def step(self, action):
        # ✅ Get Current Close Price
        past_close = self.past_df.iloc[self.current_step * self.step_size + 11]['Close']

        # ✅ Get Future Closing Price For 12 Rows
        future_prices = self._get_future_close()
        future_close = future_prices[-1]  # Last close price in the next 12 rows

        # ✅ Calculate Profit Based on Action
        reward = 0
        if action == 1:  # Buy
            if future_close > past_close:
                reward = (future_close - past_close) * 100
                self.total_profit += reward
            else:
                reward = -10  # Penalty for wrong prediction

        elif action == 2:  # Sell
            if future_close < past_close:
                reward = (past_close - future_close) * 100
                self.total_profit += reward
            else:
                reward = -10

        # ✅ Move to Next Step
        self.current_step += 1
        done = self.current_step >= self.max_steps

        # ✅ Return New State
        return self._get_observation(), reward, done, {}

    def reset(self):
        # ✅ Reset Everything
        self.current_step = 0
        self.total_profit = 0
        return self._get_observation()
