import pandas as pd
import numpy as np
import torch
import torch.nn as nn
import torch.optim as optim
import pyautogui
from TickTradingEnv import TickTradingEnv
import os


# ✅ PPO Networks
class PolicyNetwork(nn.Module):
    def __init__(self):
        super().__init__()
        self.model = nn.Sequential(
            nn.Flatten(),
            nn.Linear(12 * 5, 128),
            nn.ReLU(),
            nn.Linear(128, 3),
            nn.Softmax(dim=-1)
        )

    def forward(self, x):
        # ✅ Fix: Use .reshape() instead of .view()
        return self.model(x.reshape(1, -1))

class ValueNetwork(nn.Module):
    def __init__(self):
        super().__init__()
        self.model = nn.Sequential(
            nn.Flatten(),
            nn.Linear(12 * 5, 128),
            nn.ReLU(),
            nn.Linear(128, 1)
        )

    def forward(self, x):
        # ✅ Fix: Use .reshape() instead of .view()
        return self.model(x.reshape(1, -1))
    

# ✅ Convert Action to Click
positions = {"down": (2336, 690), "up": (2336, 531)}
def click_button(action):
    if action == 1:
        pyautogui.click(*positions['up'])
    elif action == 2:
        pyautogui.click(*positions['down'])



def save_checkpoint(policy_net, value_net, optimizer_policy, optimizer_value, episode):
    """ Save models & optimizers to resume training later """
    checkpoint = {
        'policy_net': policy_net.state_dict(),
        'value_net': value_net.state_dict(),
        'optimizer_policy': optimizer_policy.state_dict(),
        'optimizer_value': optimizer_value.state_dict(),
        'episode': episode
    }
    torch.save(checkpoint, "training_checkpoint.pth")
    print(f"✅ Saved checkpoint at Episode {episode}")

def load_checkpoint(policy_net, value_net, optimizer_policy, optimizer_value):
    """ Load checkpoint if exists """
    if os.path.exists("training_checkpoint.pth"):
        checkpoint = torch.load("training_checkpoint.pth")
        policy_net.load_state_dict(checkpoint['policy_net'])
        value_net.load_state_dict(checkpoint['value_net'])
        optimizer_policy.load_state_dict(checkpoint['optimizer_policy'])
        optimizer_value.load_state_dict(checkpoint['optimizer_value'])
        print(f"✅ Loaded checkpoint from Episode {checkpoint['episode'] + 1}")
        return checkpoint['episode'] + 1  # Resume from next episode
    return 1  # Start from Episode 1 if no checkpoint

def train_agent():
    # ✅ Load Data
    past_df = pd.read_csv('live_data10min.csv')
    future_df = pd.read_csv('live_data1min.csv')
    env = TickTradingEnv(past_df, future_df)

    # ✅ Initialize Networks
    policy_net = PolicyNetwork()
    value_net = ValueNetwork()
    optimizer_policy = optim.Adam(policy_net.parameters(), lr=0.0003)
    optimizer_value = optim.Adam(value_net.parameters(), lr=0.0003)

    # ✅ Load Checkpoint (if exists)
    start_episode = load_checkpoint(policy_net, value_net, optimizer_policy, optimizer_value)

    # ✅ Infinite Training (Auto-Resume Always)
    while True:
        state = env.reset()
        total_reward = 0

        for step in range(5):
            # ✅ Convert State to Tensor
            state_tensor = torch.FloatTensor(state)

            # ✅ Predict Action
            action_probs = policy_net(state_tensor)
            action = torch.multinomial(action_probs, 1).item()
            click_button(action)

            # ✅ Take Action
            next_state, reward, done, _ = env.step(action)
            total_reward += reward

            # ✅ Compute Loss
            value = value_net(state_tensor)
            advantage = reward - value.item()
            loss = -torch.log(action_probs.squeeze(0)[action]) * advantage

            # ✅ Optimize Policy Network
            optimizer_policy.zero_grad()
            loss.backward()
            optimizer_policy.step()

            # ✅ Optimize Value Network
            loss_value = nn.MSELoss()(
                value,
                torch.tensor([reward], dtype=torch.float32).unsqueeze(0)
            )
            optimizer_value.zero_grad()
            loss_value.backward()
            optimizer_value.step()

            # ✅ Move to Next State
            state = next_state

        print(f"✅ Episode {start_episode} Profit: {total_reward}")

        # ✅ Save Checkpoint Every 10 Episodes
        if start_episode % 10 == 0:
            save_checkpoint(policy_net, value_net, optimizer_policy, optimizer_value, start_episode)

        # ✅ Increment Episode Even After Resume
        start_episode += 1
