import csv
import time,keyboard
from datetime import datetime
import pandas as pd
from DataReader import DataReader
from train_agents import train_agent



# Function to be called when 20 minutes of data is ready for prediction
def data_ready_for_prediction(min,dataReader,file):
    print("data is ready for RL.")
    df=dataReader.fetch_recent_data(min,file)
    print("Training Agent Started")
    train_agent()


    # use the TradingEnv here..




# Function to calculate the duration of data in minutes
def calculate_data_duration(csv_filename):
    try:
        with open(csv_filename, 'r') as file:
            reader = csv.reader(file)
            # Skip the header row
            next(reader)

            # Get the timestamp of the first and last entry in the file
            rows = list(reader)
            if rows:
                first_row = rows[0]
                last_row = rows[-1]
                
                first_timestamp = datetime.fromisoformat(first_row[0])
                last_timestamp = datetime.fromisoformat(last_row[0])

                # Calculate the difference in time between the first and last timestamp
                time_diff = last_timestamp - first_timestamp
                print(time_diff)

                # Convert time difference to minutes
                data_duration_minutes = time_diff.total_seconds() / 60
                return data_duration_minutes
            else:
                return 0
    except FileNotFoundError:
        print(f"Error: {csv_filename} not found.")
        return 0
    except Exception as e:
        print(f"Error: {e}")
        return 0


# Continuously monitor the live_data.csv file
csv_filename = 'live_data.csv'
tenminfile="live_data10min.csv" # holds recent 11min-1min data
oneminfile="live_data1min.csv" #holds recent 1min data

print("Monitoring live_data.csv...")

# Establish socket connection to send statuses
dataReader = DataReader()


while True:
    # Get the duration of data available in minutes
    ready=False
    data_duration = calculate_data_duration(csv_filename)
    
    # Print the duration of the available data
    print(f"Live data consists of {int(data_duration)} minutes of data.")
    
    # Send live data status to the server
    # send_status_to_server(client_socket, f"⏳ Live data consists of {int(data_duration)} minutes of data.")

    # Check if 20 minutes of data is available
    if data_duration >=10:
        #fetch last 10min of data and write to tenminfile
        data_ready_for_prediction(10,dataReader,tenminfile)  # Call the function when 10 minutes of data is available
        # sleep for 1min
        # time.sleep(60)
        #fetch last 1min of data and write to 1min file.
        # ready=True
        # data_ready_for_prediction(1,dataReader,oneminfile,ready)

    print("In sleep for 60seconds...")
    time.sleep(60)  # Wait for 60 seconds before checking again
    
